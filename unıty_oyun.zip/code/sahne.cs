﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class sahne : MonoBehaviour
{
  
 
public void sahnedegis()
{
    SceneManager.LoadScene("kavga");
}
}
