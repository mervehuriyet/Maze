﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine;

public class Pause : MonoBehaviour
{
    
    public static bool isPaused; 
    void Update()
    {

        if (Input.GetKeyDown(KeyCode.P)) 
        {
            if (isPaused) 
            {
                Time.timeScale = 1;
                isPaused = false;
                //pauseMenu.SetActive(false);
            }
            else          {
                Time.timeScale = 0;
                isPaused = true;
                //pauseMenu.SetActive(true);
            }
        }
    }

     void OnGUI()
     {
         if (isPaused) 
         {
             GUILayout.Label(" Resume...");
           // pauseMenu.SetActive(true);

            //SceneManager.LoadScene("pause");
        }
     }
    
     
    
}
