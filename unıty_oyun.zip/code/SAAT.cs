﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class SAAT : MonoBehaviour
{

    public Text sayacText;
    public float saniye, dakika, saat, gun;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        saniye += Time.deltaTime;
        if (Mathf.RoundToInt(saniye) > 59)
        {
            saniye = 0;
            dakika++;
        }
        if (Mathf.RoundToInt(dakika) > 59)
        {
            dakika = 0;
            saat++;
        }
        if (Mathf.RoundToInt(saat) > 23)
        {
            saat = 0;
            gun++;
        }
        sayacText.text = Mathf.RoundToInt(gun).ToString("D1") + ":" + Mathf.RoundToInt(saat).ToString("D2") + ":" + Mathf.RoundToInt(dakika).ToString("D2") + ":" + Mathf.RoundToInt(saniye).ToString("D2");

    }
}
/*
 
 saniye += Time.deltaTime;
        if (Mathf.RoundToInt(saniye) > 59)
        {
            saniye = 0;
            dakika++;
        }
        if (Mathf.RoundToInt(dakika) > 59)
        {
            dakika = 0;
            saat++;
        }
        if (Mathf.RoundToInt(saat) > 23)
        {
            saat = 0;
            gun++;
        }
        sayacText.text = Mathf.RoundToInt(gun).ToString("D1") + ":" + Mathf.RoundToInt(saat).ToString("D2") + ":" + Mathf.RoundToInt(dakika).ToString("D2") + ":" + Mathf.RoundToInt(saniye).ToString("D2");
  
 */
