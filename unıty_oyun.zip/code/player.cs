﻿using UnityEngine;

using System.Collections;

using UnityEngine.UI;



public class player2 : MonoBehaviour
{



    //public GameObject gold;

    public Text skortxt;

    public int skor;
    void Start()

    {

        //GetComponent<BoxCollider>().enabled = false;

        //GetComponent<BoxCollider>().isTrigger = true;

        //GetComponent<MeshRenderer>().enabled = false;

        //GetComponent<hareket>().enabled = false;

        //GetComponent<Rigidbody>().useGravity = false;

        //GetComponent<Transform>().localScale = new Vector3 (2,2,2);

    }

    void Update()

    {

    }

    void OnTriggerEnter(Collider temas)

    {

        if (temas.gameObject.tag == "gold")

        {

            skor++;

            skortxt.text = skor.ToString();

            Destroy(temas.gameObject);

        }

    }

}