﻿using UnityEngine;


using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class mm : MonoBehaviour
{

    // Use this for initialization
    public Text skortxt;
    public AudioClip altinses;

    public float hiz = 10f;
    public int skor;
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

        float zYonu = Input.GetAxis("Vertical") * hiz;
        float xYonu = Input.GetAxis("Horizontal") * hiz;
        zYonu *= Time.deltaTime;
        xYonu *= Time.deltaTime;
        transform.Translate(xYonu, 0, zYonu);







        /*
                if (Input.GetKey(KeyCode.RightArrow))
                {
                    GetComponent<Rigidbody>().AddForce(Vector3.right * 30);
                }
                if (Input.GetKey(KeyCode.LeftArrow))
                {
                    GetComponent<Rigidbody>().AddForce(Vector3.left * 30);
                }
                if (Input.GetKey(KeyCode.UpArrow))
                {
                    GetComponent<Rigidbody>().AddForce(Vector3.forward * 30);
                }
                if (Input.GetKey(KeyCode.DownArrow))
                {
                    GetComponent<Rigidbody>().AddForce(Vector3.back * 30);

                }


            }
            */
    }
        void OnTriggerEnter(Collider temas)

    {

        if (temas.gameObject.tag == "altin")

        {

            skor++;

            string v = skor.ToString();
            skortxt.text = v;
            GetComponent<AudioSource>().PlayOneShot(altinses);
            Destroy(temas.gameObject);
           
        }
        if (temas.gameObject.tag == "end")

        {

            SceneManager.LoadScene("kavga");

        }

    }
    

        







    }
